---
name: markdown-to-email
description: "Use when replying by email and wanting to send HTML-formatted responses rendered inline (not as an attachment). Converts markdown to HTML and delivers via himalaya MML multipart/alternative."
version: 2.1.0
author: Bitcoin Wizard
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [email, markdown, html, conversion, himalaya]
    related_skills: [himalaya]
---

# Markdown to HTML Email — v2.1 (Default Pipeline)

## Overview

When Hermes replies by email, the built-in gateway sends only `text/plain` —
any markdown formatting is lost. This skill **overrides** that by teaching the
agent to instead write responses in markdown, convert them to HTML using a
pure-Python script, and send them via **himalaya** as multipart/alternative
emails with both a `text/plain` fallback and inline `text/html` rendering.

**When this skill is loaded, ALL email replies go through the himalaya
pipeline automatically.** The HTML renders inline in the email client —
Gmail, Fastmail, Outlook, Thunderbird all show the formatted version directly
in the message pane. No file attachments, no raw markdown characters.

## How It Works

```
Write response in markdown
        │
        ▼
   python3 md2email.py <<< "$MD"   (markdown → HTML)
        │
        ▼
   Build MML multipart/alternative:
     - text/plain part (markdown body = fallback)
     - text/html part  (rendered HTML body)
        │
        ▼
   himalaya template send          (SMTP delivery)
        │
        ▼
   Recipient sees HTML rendered inline
```

## Default Workflow

**When replying by email with this skill loaded, ALWAYS follow these steps:**

### Step 1: Write the response in markdown

Compose the full response using GitHub-Flavored Markdown inside a heredoc:

```bash
MD_CONTENT=$(cat << 'HERMES_MD'
# Heading

**bold** *italic* `code`

- list item

> blockquote

```
code block
```

HERMES_MD
)
```

### Step 2: Convert to HTML

```bash
HTML_CONTENT=$(python3 /home/hermes/.hermes/skills/email/markdown-to-email/scripts/md2email.py <<< "$MD_CONTENT")
```

### Step 3: Build and send via himalaya

```bash
{
  echo "From: wizard-u3@hxmt.xyz"
  echo "To: $RECIPIENT_EMAIL"
  echo "Subject: Re: $ORIGINAL_SUBJECT"
  echo ""
  echo '<#multipart type=alternative>'
  echo "$MD_CONTENT"
  echo ''
  echo '<#part type=text/html>'
  echo "$HTML_CONTENT"
  echo '<#/multipart>'
} | himalaya template send
```

### Step 4: Deliver clean text to the gateway

The Hermes gateway always sends a plain-text copy. To avoid raw markdown
characters (`**bold**`, `# Header`) leaking into it, write the gateway
response as clean plain text with NO markdown syntax. A simple summary
works:

```
HTML version sent via himalaya — check your inbox for formatted rendering.
```

## Supported Markdown

- H1–H6: `# Heading`
- Bold: `**text**`
- Italic: `*text*`
- Strikethrough: `~~text~~`
- Inline code: `` `code` ``
- Code blocks: ``` ``` ```
- Links: `[text](url)`
- Images: `![alt](url)`
- UL lists: `- item`
- OL lists: `1. item`
- Blockquotes: `> text`
- Horizontal rule: `---`

## Email CSS Features

- System font stack, max-width 640px
- Dark mode via `@media (prefers-color-scheme: dark)`
- Semantic code/blockquote styling
- No JavaScript or external resources

## Verification Checklist

- [ ] himalaya installed (`~/.local/bin/himalaya --version`)
- [ ] markdown response written in `MD_CONTENT`
- [ ] HTML generated via `md2email.py`
- [ ] MML multipart/alternative built
- [ ] `himalaya template send` returns "Message successfully sent!"
- [ ] Gateway response written as clean plain text (no markdown chars)